import React from 'react';

const Result = () => {
  return (
    <div className="result">
      <h2>Thank you for your message!</h2>
      <p>We appreciate your feedback and will get back to you shortly. In the meantime, feel free to browse our latest books.</p>
    </div>
  );
};

export default Result;