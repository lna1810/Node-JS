import React from 'react';

const Services = () => {
  return (
    <div className="services">
      <h1>Our Services</h1>
      <p>We offer a variety of services to enhance your bookshopping experience.</p>
      <ul>
        <li>Book Recommendations: Personalized suggestions based on your reading preferences.</li>
        <li>Gift Cards: Purchase gift cards for your friends and family to enjoy the gift of books.</li>
        <li>Book Club Membership: Join our book club for exclusive discounts and event invitations.</li>
        <li>Online Ordering: Browse and order books online with convenient delivery options.</li>
      </ul>
    </div>
  );
};

export default Services;