import React from 'react';
import './styles.css';

const About = () => {
  return (
    <div className="about">
      <h1>About Us</h1>
      <p>Welcome to our Bookshop! We are passionate about bringing you the best selection of books.</p>
      <p>Our mission is to provide a wide variety of books for readers of all ages and interests.</p>
      <p>Visit us to find your next great read, or contact us for more information about our books and services.</p>
    </div>
  );
};

export default About;