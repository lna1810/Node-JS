import React from 'react';

const Home = () => {
  return (
    <div className="home">
      <h1>Welcome to Our Bookshop</h1>
      <p>We are excited to have you here. Browse through our wide selection of books for every taste and age group.</p>
      <p>Whether you're looking for fiction, non-fiction, bestsellers, or children's books, we have something for everyone!</p>
      <p>Feel free to contact us if you need book recommendations or more information about our collection.</p>
    </div>
  );
};

export default Home;